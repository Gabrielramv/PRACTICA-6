

#include <stdio.h>
#include <stdlib.h>

void fun1(int *a1)
{
int i;
char div[]="-------------------------------";
printf("Funcion i:\n");
 for(i=0;i<5;i++)
 {
 printf("%d\t",a1[i]); 				 
 } 	 
printf("\n%s\n",div); 
}

void fun2(int *a1, int *a2, int *a3)
{
int i,res;
printf("Funcion ii:\nArreglo original:\n");
 for(i=0;i<5;i++)
 {
 printf("%d\t",a1[i]);				 
 } 	
printf("\nArreglo No. 2:\n");
 for(i=0;i<5;i++)
 {
 printf("%d\t",a2[i]);				 
 } 
printf("\nSuma de los dos arreglos:\n");
 for(i=0;i<5;i++)
 {
 a3[i]=a1[i]+a2[i];			 
 } 	 
}
 
void fun3(int *a1, int *a4)
{
int i;
char div[]="-------------------------------";
printf("Funcion iii:\nArreglo original:\n"); 
 for(i=0;i<5;i++)
 {
 printf("%d\t",a1[i]);
 a4[4-i]=a1[i];			 
 } 	
printf("\nArreglo invertido:\n");
for(i=0;i<5;i++)
 {
 printf("%d\t",a1[4-i]); 				 
 }	 
printf("\n%s\n",div);
}

void fun4(int *a1, char *a5)
{
int i;
printf("Funcion iv:\nArreglo original:\n");
 for(i=0;i<5;i++)
 {
 printf("%d\t",a1[i]);				 
 } 
printf("\nArreglo par o impar:\n");
 for(i=0;i<5;i++)
 {
  if(a1[i]%2==0)
  {
  a5[i]='P';			  
  } 			
  else
  {
  a5[i]='I'; 	  
  }	 
 }	
}

int main(int argc, char *argv[])
{
int arreglo1[]={3,5,8,2,1},arreglo2[]={8,9,5,1,4},arreglo3[8],arreglo4[8],i;
char arreglo5[8];
int *a1,*a2,*a3,*a4;
char *a5;
char div[]="-------------------------------";

a1=&arreglo1;
a2=&arreglo2;
a3=&arreglo3;
a4=&arreglo4;
a5=&arreglo5;

fun1(a1);
fun2(a1,a2,a3);
 for(i=0;i<5;i++)
 {
 printf("%d\t",a3[i]);			 
 } 
printf("\n%s\n",div);
fun3(a1,a4);
fun4(a1,a5);
 for(i=0;i<5;i++)
 {
 printf("%c\t",a5[i]);
 }
printf("\n%s\n",div);
system("PAUSE");	
return 0;
}
