#include <stdio.h>
#include <stdlib.h>

int sumar(int a,int b);

int main(int argc, char *argv[])
{
int num1;
int num2;
num1=5;
num2=8;
int total=sumar(num1,num2); 
printf("num1= %d\n",num1); 
printf("num2= %d\n",num2); 
printf("total= %d\n",total); 
system("PAUSE");	
return 0;
}

int sumar(int a,int b)
{
int c=0;
c=a+b;
return c;
}
