#include <stdio.h>
#include <stdlib.h>

int sumar(int *a,int *b);

int main(int argc, char *argv[])
{
int *num1=(int*)malloc(sizeof(int));
int *num2=(int*)malloc(sizeof(int));
*num1=5;
*num2=8;
int total=sumar(num1,num2);
printf("Num1= %d\n",*num1);
printf("Num2= %d\n",*num2);
printf("Num3= %d\n",total);
system("PAUSE");	
return 0;
}

int sumar(int *a,int *b)
{
int c=0;
c=(*a)+(*b);
return c;
}
